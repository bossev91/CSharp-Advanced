﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Person Pesho = new Person();
            Person Gosho = new Person("Gosho", 18);
            Person Stamat = new Person("Stamat", 43);

            
           
        }
    }
}
